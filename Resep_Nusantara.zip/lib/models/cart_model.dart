class CartModel {
  int menuId;
  int quantity;

  CartModel({this.menuId, this.quantity});
}
