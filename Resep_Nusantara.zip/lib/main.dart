// ignore_for_file: prefer_const_constructors

import 'package:chef/screens/favorite/favorite_controller.dart';
import 'package:chef/screens/splash/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'screens/favorite/favorite_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final FavoriteController favoriteController = Get.put(FavoriteController());

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Chef App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber),
        useMaterial3: true,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
      routes: {
        FavoriteScreen.routeName: (context) => FavoriteScreen(
              favoriteRecipes: [],
            ),
      },
    );
  }
}
