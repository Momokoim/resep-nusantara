// ignore_for_file: deprecated_member_use, unnecessary_import, sdk_version_async_exported_from_core

import 'dart:convert';
import 'package:chef/screens/detail/detail_screen.dart';
import 'package:chef/screens/favorite/favorite_controller.dart';
import 'package:chef/screens/favorite/favorite_screen.dart';
import 'package:chef/screens/profile/profile_screen.dart';
import 'package:flutter/material.dart' hide Badge;
import 'package:google_fonts/google_fonts.dart';
// ignore: library_prefixes
import 'package:http/http.dart' as myHttp;
import 'package:url_launcher/url_launcher.dart';
import '../../models/menu_model.dart';
import 'package:flutter/cupertino.dart';

class HomeScreen extends StatefulWidget {
  final MenuModel menuModel;

  const HomeScreen({Key key, this.menuModel}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();

  static firstWhere(bool Function(dynamic place) param0) {}
}

TextEditingController searchController = TextEditingController();

class _HomeScreenState extends State<HomeScreen> {
  final String urlMenu =
      "https://script.google.com/macros/s/AKfycbz-Sl6v9CLy5jjsFMAZiwcfuSqpgkjoIQflPAdyeDk_h5_HAd6NvK_JShD-HGHHoSs/exec";

  final FavoriteController favoriteController = FavoriteController();

  get query => searchController.text;

  get data => null;

  get menuModel => null;

  Future<List<MenuModel>> getAllData(String name) async {
    List<MenuModel> listMenu = [];
    var response = await myHttp.get(Uri.parse(urlMenu + '?query=$name'));
    List data = json.decode(response.body);

    for (var element in data) {
      MenuModel menu = MenuModel.fromJson(element);
      if (menu.name.toLowerCase().contains(name.toLowerCase())) {
        listMenu.add(menu);
      }
    }

    return listMenu;
  }

  Future<void> openWebSource() async {
    if (menuModel == null) {
      return;
    }
    final Uri url = Uri.parse(menuModel.sourceUrl);
    if (!await canLaunch(url.toString())) {
      throw Exception('Could not launch $url');
    }
    await launch(url.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        shadowColor: Colors.transparent,
        elevation: 0.0,
        title: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0), // Adjust the padding
              child: Row(
                children: [
                  Text(
                    'Hai, Chef',
                    style: GoogleFonts.playfairDisplay(
                      textStyle: TextStyle(
                        color: Colors.black,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 0,
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FavoriteScreen(
                            favoriteRecipes: favoriteController.favoriteRecipes,
                          ),
                        ),
                      );
                    },
                    icon: Icon(
                      Icons.favorite,
                      size: 23,
                      color: Colors.red,
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProfileScreen(),
                        ),
                      );
                    },
                    icon: Icon(
                      Icons.more_vert_outlined,
                      size: 25,
                      color: Color.fromARGB(255, 7, 7, 8),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: TextField(
                controller: searchController,
                onSubmitted: (value) {
                  setState(() {
                    if (searchController.text.isEmpty) {
                      getAllData('').then((data) {
                        // Lakukan sesuatu dengan data (misalnya, set nilai variabel snapshot)
                      });
                    } else {
                      getAllData(searchController.text).then((data) {
                        // Lakukan sesuatu dengan data (misalnya, set nilai variabel snapshot)
                      });
                    }
                  });
                },
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                  fontWeight:
                      FontWeight.bold, // Mengatur ukuran font menjadi 18
                ),
                decoration: InputDecoration(
                  labelText: 'Cari Resep',
                  contentPadding: EdgeInsets.symmetric(
                    vertical: 12,
                    horizontal: 16,
                  ),
                  fillColor: Colors.grey[200], // Mengatur warna latar belakang
                  filled: true, // Mengisi latar belakang dengan warna
                  border: OutlineInputBorder(
                    // Mengatur border
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none, // Menghilangkan border
                  ),
                  suffixIcon: IconButton(
                    onPressed: () async {
                      setState(() {
                        if (searchController.text.isEmpty) {
                          getAllData('').then((data) {
                            // Lakukan sesuatu dengan data (misalnya, set nilai variabel snapshot)
                          });
                        } else {
                          getAllData(searchController.text).then((data) {
                            // Lakukan sesuatu dengan data (misalnya, set nilai variabel snapshot)
                          });
                        }
                      });
                    },
                    icon: Icon(Icons.search),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: FutureBuilder(
                  future: searchController.text.isEmpty
                      ? getAllData('')
                      : getAllData(searchController.text),
                  builder: (context, AsyncSnapshot<List<MenuModel>> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else {
                      if (snapshot.hasData) {
                        final List<MenuModel> data = snapshot.data;
                        if (data.isEmpty) {
                          return const Center(
                            child: Text("Tidak ada data"),
                          );
                        } else {
                          return GridView.builder(
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              childAspectRatio: 0.75,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10,
                            ),
                            itemCount: data.length,
                            itemBuilder: (context, index) {
                              MenuModel menu = data[index];
                              return GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          DetailScreen(menu: menu),
                                    ),
                                  );
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.2),
                                        offset: Offset(0, 2),
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Column(
                                      children: [
                                        Expanded(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: NetworkImage(menu.image),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8),
                                          child: Text(
                                            menu.name,
                                            style: GoogleFonts.montserrat(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        }
                      } else if (snapshot.hasError) {
                        return const Center(
                          child: Text("Terjadi kesalahan"),
                        );
                      } else {
                        return const Center(
                          child: Text("Tidak ada data"),
                        );
                      }
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
