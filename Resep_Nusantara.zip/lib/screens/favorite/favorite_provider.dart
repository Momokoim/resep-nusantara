import 'package:flutter/foundation.dart';
import 'package:chef/models/menu_model.dart';

class FavoriteProvider with ChangeNotifier {
  List<MenuModel> _favoriteRecipes = [];

  List<MenuModel> get favoriteRecipes => _favoriteRecipes;

  void addFavoriteRecipe(MenuModel recipe) {
    _favoriteRecipes.add(recipe);
    notifyListeners();
  }

  void removeFavoriteRecipe(MenuModel recipe) {
    _favoriteRecipes.remove(recipe);
    notifyListeners();
  }
}
