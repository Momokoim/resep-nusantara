// ignore_for_file: unused_import, unused_local_variable, sdk_version_async_exported_from_core, invalid_use_of_protected_member

import 'package:chef/models/menu_model.dart';
import 'package:chef/screens/favorite/favorite_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../detail/detail_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavoriteScreen extends StatefulWidget {
  final List<MenuModel> favoriteRecipes;
  static const String routeName = '/favorite';

  const FavoriteScreen({Key key, this.favoriteRecipes}) : super(key: key);

  @override
  _FavoriteScreenState createState() => _FavoriteScreenState();
}

class _FavoriteScreenState extends State<FavoriteScreen> {
  final FavoriteController favoriteController = Get.find();
  List<MenuModel> favoriteRecipes = [];

  @override
  void initState() {
    super.initState();
    favoriteController.fetchAllRecipes().then((_) {
      favoriteController.loadFavoriteRecipes();
      loadFavoriteRecipes();
    });
  }

  @override
  void dispose() {
    saveFavoriteRecipes();
    super.dispose();
  }

  Future<void> saveFavoriteRecipes() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = favoriteRecipes.map((recipe) {
      return recipe.id.toString();
    }).toList();

    await prefs.setStringList('favoriteIds', favoriteIds);
  }

  Future<void> loadFavoriteRecipes() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];

    final List<MenuModel> loadedRecipes =
        favoriteController.allRecipes.value.where((recipe) {
      return favoriteIds.contains(recipe.id.toString());
    }).toList();

    setState(() {
      favoriteRecipes = loadedRecipes;
    });
  }

  Future<void> toggleFavorite(MenuModel recipe) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];

    if (favoriteIds.contains(recipe.id.toString())) {
      favoriteIds.remove(recipe.id.toString());
      favoriteRecipes.remove(recipe);
    } else {
      favoriteIds.add(recipe.id.toString());
      favoriteRecipes.add(recipe);
    }

    await prefs.setStringList('favoriteIds', favoriteIds);

    setState(
        () {}); // Add this line to update the UI after modifying the favoriteRecipes list
  }

  @override
  Widget build(BuildContext context) {
    final List<MenuModel> favoriteRecipes = favoriteController.favoriteRecipes;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text(
          'Resep Favorite ',
          style: GoogleFonts.playfairDisplay(
            textStyle: TextStyle(
              color: Colors.black,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        centerTitle: true,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 10.0,
          crossAxisSpacing: 10.0,
          childAspectRatio: 0.75, // Adjust the aspect ratio of each item
        ),
        itemCount: favoriteRecipes.length,
        itemBuilder: (context, index) {
          final recipe = favoriteRecipes[index];
          return GestureDetector(
            onTap: () async {
              await toggleFavorite(recipe);
              setState(() {
                favoriteController.toggleFavorite(recipe);
              });
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailScreen(menu: recipe),
                ),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    offset: Offset(0, 2),
                    blurRadius: 6.0,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: Column(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage(recipe.image),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 8.0),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        recipe.name,
                        style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
