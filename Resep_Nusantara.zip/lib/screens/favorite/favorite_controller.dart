// ignore_for_file: sdk_version_async_exported_from_core, unused_local_variable

import 'package:chef/models/menu_model.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavoriteController extends GetxController {
  final RxList<MenuModel> favoriteRecipes = <MenuModel>[].obs;
  RxList<MenuModel> allRecipes = RxList<MenuModel>.empty();

  Future<void> fetchAllRecipes() async {
    // Lakukan logika untuk mengambil semua resep dari API atau sumber data lainnya
    // dan mengisi `allRecipes` dengan daftar resep yang diperoleh.
  }
  Future<void> toggleFavorite(MenuModel recipe) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];

    if (favoriteIds.contains(recipe.id.toString())) {
      favoriteIds.remove(recipe.id.toString());
      favoriteRecipes.remove(recipe);
    } else {
      favoriteIds.add(recipe.id.toString());
      favoriteRecipes.add(recipe);
    }

    await prefs.setStringList('favoriteIds', favoriteIds);
  }

  Future<void> updateFavoritesFromPrefs() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];

    // Menghapus resep dari daftar favorit yang tidak ada lagi dalam SharedPreferences
    favoriteRecipes
        .removeWhere((recipe) => !favoriteIds.contains(recipe.id.toString()));

    // Menambah resep ke daftar favorit yang ada di SharedPreferences
    for (final id in favoriteIds) {
      final int recipeId = int.tryParse(id);
      if (recipeId != null) {
        final existingRecipe = favoriteRecipes.firstWhere(
          (recipe) => recipe.id == recipeId,
          orElse: () => null,
        );
        if (existingRecipe == null) {
          final recipe = await fetchRecipeById(recipeId);
          if (recipe != null) {
            favoriteRecipes.add(recipe);
          }
        }
      }
    }

    update(); // Memperbarui tampilan setelah mengupdate daftar favorit
  }

  Future<void> loadFavoriteRecipes() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];

    for (final recipe in favoriteRecipes) {
      if (!favoriteIds.contains(recipe.id.toString())) {
        favoriteRecipes.remove(recipe);
      }
    }

    for (final id in favoriteIds) {
      final int recipeId = int.tryParse(id);
      if (recipeId != null) {
        final recipe = await loadRecipe(recipeId);
        if (recipe != null) {
          favoriteRecipes.add(recipe);
        }
      }
    }
  }

  Future<MenuModel> loadRecipe(int id) {
    // Logic to load the recipe from a data source
    // based on the provided ID
    // Return the loaded recipe or null if not found
    // Example:
    // final recipe = await RecipeService.getRecipeById(id);
    // return recipe;
    return null;
  }

  fetchRecipeById(int recipeId) {}
}
