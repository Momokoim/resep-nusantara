import '../../models/menu_model.dart';

class FavoriteRecipes {
  static List<MenuModel> recipes = [];
}
