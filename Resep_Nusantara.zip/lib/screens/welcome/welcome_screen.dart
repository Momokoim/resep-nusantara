// ignore_for_file: use_key_in_widget_constructors, prefer_const_constructors, sized_box_for_whitespace

import 'package:chef/screens/home/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class WelcomeScreen extends StatelessWidget {
  get menuModel => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(
                  'assets/images/welcome_screen.svg',
                  width: 200,
                  height: 200,
                ),
                SizedBox(height: 16),
                Text(
                  'Temukan Resep Nusantara',
                  style: GoogleFonts.playfairDisplay(
                    textStyle: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black, // Set the text color to black
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Jelajahi berbagai macam resep lezat Nusantara untuk memuaskan hasrat kuliner Anda.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.openSans(
                    textStyle: TextStyle(
                      fontSize: 16,
                      color: Colors.grey, // Set the text color to grey
                    ),
                  ),
                ),
                SizedBox(height: 32.0),
                Column(
                  children: [
                    Container(
                      width: double.infinity,
                      height: 40,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                          primary:
                              Colors.amber, // Set the button color to green
                        ),
                        child: Text(
                          'Start',
                          style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color:
                                  Colors.black, // Set the text color to white
                            ),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  HomeScreen(menuModel: menuModel),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
