import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:url_launcher/url_launcher.dart';

class AccountScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          shrinkWrap: true,
          children: <Widget>[
            Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back_ios),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    Spacer(),
                    Text(
                      'Account Info',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 24),
                SvgPicture.asset(
                  'assets/images/developer.svg',
                  width: 200,
                  height: 200,
                ),
                SizedBox(height: 24),
                GestureDetector(
                  onTap: () {
                    launch(
                        'https://www.facebook.com/profile.php?id=100009920018543&mibextid=ZbWKwL');
                  },
                  child: ListTile(
                    leading: Icon(Icons.facebook, size: 24),
                    title: Text(
                      'Facebook',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      'Dianacatur',
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ),
                Divider(),
                GestureDetector(
                  onTap: () {
                    launch('mailto:dianacatur25@gmail.com');
                  },
                  child: ListTile(
                    leading: Icon(Icons.mail, size: 24),
                    title: Text(
                      'Email',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      'dianacatur25@gmail.com',
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ),
                Divider(),
                GestureDetector(
                  onTap: () {
                    launch(
                      'https://instagram.com/dianacatur25?igshid=MWQ1ZGUxMzBkMA==',
                    );
                  },
                  child: ListTile(
                    leading: SvgPicture.asset(
                      'assets/images/instagram.svg', // Replace with the path to your custom SVG icon
                      width: 24,
                      height: 24,
                    ),
                    title: Text(
                      'Instagram',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      'dianacatur25',
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ),
                SizedBox(height: 24),
                Text(
                  '',
                  style: TextStyle(fontSize: 18),
                ),
                SizedBox(height: 16),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
