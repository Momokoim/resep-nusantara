// ignore_for_file: use_key_in_widget_constructors, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AppInfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_ios),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                Spacer(),
                Text(
                  'App Info',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),
            SvgPicture.asset(
              'assets/images/splash_screen.svg',
              width: 200,
              height: 200,
            ),
            SizedBox(height: 24),
            ListTile(
              leading: Icon(Icons.food_bank, size: 24),
              title: Text(
                'Masak',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                'Siap menjadi koki di rumah mu!',
                style: TextStyle(fontSize: 14),
              ),
            ),
            Divider(),
            SizedBox(height: 8.0),
            ListTile(
              leading: Icon(Icons.home, size: 24),
              title: Text(
                'Application Name',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                'Resep Nusantara',
                style: TextStyle(fontSize: 14),
              ),
            ),
            Divider(),
            SizedBox(height: 24),
            Text(
              'Version: 1.0.0',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
