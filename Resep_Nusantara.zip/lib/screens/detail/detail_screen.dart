// ignore_for_file: unused_field, sdk_version_async_exported_from_core

import 'package:chef/screens/detail/full_screen_image.dart';
import 'package:chef/screens/favorite/favorite_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/menu_model.dart';

class DetailScreen extends StatefulWidget {
  final MenuModel menu;
  DetailScreen({Key key, this.menu}) : super(key: key);

  @override
  _DetailScreenState createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  final FavoriteController favoriteController = Get.find();

  bool _showIngredients = false;
  bool _showSteps = false;
  bool _isFavorite = false;

  @override
  void initState() {
    super.initState();
    _checkIsFavorite();
  }

  Future<void> _checkIsFavorite() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];
    setState(() {
      _isFavorite = favoriteIds.contains(widget.menu.id.toString());
    });
  }

  List<MenuModel> favoriteRecipes = [];

  Future<void> _toggleFavorite(MenuModel menu) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> favoriteIds = prefs.getStringList('favoriteIds') ?? [];

    if (favoriteIds.contains(menu.id.toString())) {
      favoriteIds.remove(menu.id.toString());
    } else {
      favoriteIds.add(menu.id.toString());
    }

    await prefs.setStringList('favoriteIds', favoriteIds);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Center(
          child: Text(
            'Detail Resep',
            style: GoogleFonts.playfairDisplay(
              textStyle: TextStyle(
                color: Colors.black,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                favoriteController.toggleFavorite(widget.menu);
              });
            },
            icon: Obx(() => Icon(
                  favoriteController.favoriteRecipes.contains(widget.menu)
                      ? Icons.favorite
                      : Icons.favorite_border,
                  color: Colors.red,
                )),
          ),
        ],
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FullScreenImage(
                        imageUrl: widget.menu.image,
                      ),
                    ),
                  );
                },
                child: Hero(
                  tag: 'recipe_image',
                  child: Container(
                    width: double.infinity,
                    height: 200,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: NetworkImage(widget.menu.image),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Text(
                  widget.menu.name,
                  style: GoogleFonts.montserrat(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.menu.description,
                style: GoogleFonts.montserrat(
                  fontSize: 16,
                ),
                textAlign: TextAlign.justify,
              ),
              const SizedBox(height: 24),
              ExpansionTile(
                title: Text(
                  'Bahan Bahan:',
                  style: GoogleFonts.montserrat(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                children: [
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: widget.menu.ingredients.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4.0),
                        child: Row(
                          mainAxisAlignment:
                              MainAxisAlignment.start, // Align text to left
                          children: [
                            Icon(
                              Icons.check_circle,
                              size: 14,
                              color: Colors.green,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                widget.menu.ingredients[index],
                                style: GoogleFonts.montserrat(
                                  fontSize: 14,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
                onExpansionChanged: (value) {
                  setState(() {
                    _showIngredients = value;
                  });
                },
                initiallyExpanded: _showIngredients,
              ),
              const SizedBox(height: 24),
              ExpansionTile(
                title: Text(
                  'Cara Memasak:',
                  style: GoogleFonts.montserrat(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                children: [
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: widget.menu.step.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4.0),
                        child: Row(
                          crossAxisAlignment:
                              CrossAxisAlignment.start, // Align text to top
                          children: [
                            Container(
                              width: 24,
                              child: Text(
                                '${index + 1}.',
                                style: GoogleFonts.montserrat(fontSize: 14),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                widget.menu.step[index],
                                style: GoogleFonts.montserrat(fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
                onExpansionChanged: (value) {
                  setState(() {
                    _showSteps = value;
                  });
                },
                initiallyExpanded: _showSteps,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
